package com.testkafka

import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka010.{ConsumerStrategies, HasOffsetRanges, KafkaUtils, LocationStrategies}
import org.apache.commons.lang3.StringUtils;
object testKafka2 {
  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setMaster("local[*]").setAppName("test01")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val ssc = new StreamingContext(spark.sparkContext,Seconds(5))
    val KafkaParams = Map[String, Object](
      "bootstrap.servers" -> "192.168.110.140:9092",
      "key.deserializer" -> classOf[StringDeserializer],
      "value.deserializer" -> classOf[StringDeserializer],
      "group.id" -> "test-consumer-group",
      "auto.offset.reset" -> "latest",
      "enable.auto.commit" -> (false:java.lang.Boolean)
    )
    val topics = Array("myhello")
    //    KafkaUtils.createDirectStream[String, String,StringDecoder,StringDecoder](
    //      ssc, KafkaParams, topics)

    val stream = KafkaUtils.createDirectStream(
      ssc,
      LocationStrategies.PreferConsistent,
      ConsumerStrategies.Subscribe[String, String](topics, KafkaParams)
    )
    stream.foreachRDD(rdd => {
      val offsetRange = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
      val lines=rdd.map(_.value())
      val files =lines.flatMap(_.split(" ").slice(3,4))
      val pair = files.map(x=>(x,1))
      val wordCounts = pair.reduceByKey(_+_)
      wordCounts.foreach(println)

    })
    ssc.start()
    ssc.awaitTermination()
  }

}
